// import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <h1>My First React App</h1>
  );
}

export default App;
