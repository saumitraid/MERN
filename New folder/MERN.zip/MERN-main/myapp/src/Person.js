export class Person{
    constructor(name){
      this.name=name;
    }
    walk(){
      console.log('Can walk');
    }
}
